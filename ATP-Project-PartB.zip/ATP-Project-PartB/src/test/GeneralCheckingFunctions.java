package test;

public class GeneralCheckingFunctions {

    public static boolean check3DMaze(){
        // If you have chosen to not do the Maze3D assignment,
        // Please change this value to false.
        
        boolean weChoseToDoTheMaze3DAssignment = true;
        return weChoseToDoTheMaze3DAssignment;
    }

    public static String getGithubLink(){
        String githubLink = "https://github.com/OmerHanan1/ATP-Project";
        return githubLink;
    }
}