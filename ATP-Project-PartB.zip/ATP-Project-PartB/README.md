# ATP-Project-PartA

## Maze generation - Project Idea:
Create maze game using Design patterns and software architecture principles from the course.
the first part is about Generating mazes.


![ATP-partA](https://user-images.githubusercontent.com/79142560/163842866-4fb0bad8-b2d7-4f05-8e47-766a18bf67c0.jpg)

## Authors: 
Omer Hanan, Eden Naroditzky 
